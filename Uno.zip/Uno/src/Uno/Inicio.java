package Uno;

import java.util.Scanner;

public class Inicio {

	public static void main(String[] args) {
		// Esto es un comentario de una linea
		  /* 
		   * Esto es un comentario de varias lieas
				1 Se ingresa un numero y se informa o muestra el numero ingresado.
				2 Se ingresan 2 numeros y se muestra la suma de los mismos.
				3 Se ingresan 3 numeros y se muestra el promedio.
				4 Se ingresa la base de un cuadrado y se informa el perimetro del mismo.
				5 Se pide un precio de un producto y se le muestra el importe mas el IVA.		  
		  */
		 // System.out.println("Hola Mundo Leonardo");
		 // 1 Se muestra el numero ingresado
	  /* Scanner Teclado = new Scanner (System.in);
         System.out.println("Ingrese Numero:");
         int Numero;
         Numero = Teclado.nextInt();
         System.out.println("El Numero ingresado es:");
         System.out.println(Numero); */
		 
         // 2 Se ingresan 2 numeros y se muestra el producto
     /*    Scanner Teclado = new Scanner (System.in);
         System.out.println("Ingrese Numero:");
         int Numero;
         Numero = Teclado.nextInt();
         System.out.println("El cuadrado es:");
         System.out.println(Numero*Numero); */
       
         // Se ingresan 2 numeros se muestran los numeros y despues se muestra la suma de los mismos
    /*     Scanner Teclado = new Scanner (System.in);
         System.out.println("Ingrese Numero 1:");
         int Numero1;
         Numero1 = Teclado.nextInt();
         System.out.println("Ingrese Numero 2:");
         int Numero2;
         Numero2 = Teclado.nextInt();
         System.out.println("Los numeros ingresados son:");
         System.out.println(Numero1);
         System.out.println(Numero2);
         System.out.println("La suma de los numeros es:");
         System.out.println(Numero1+Numero2); */

        // Se ingresan 2 numeros se muestran los numeros y despues se muestra el promedio
     /* Scanner Teclado = new Scanner (System.in);
        System.out.println("Ingrese Numero 1:");
        int Numero1;
        Numero1 = Teclado.nextInt();
        System.out.println("Ingrese Numero 2:");
        int Numero2;
        Numero2 = Teclado.nextInt();
        System.out.println("Ingrese Numero 3:");
        int Numero3;
        Numero3 = Teclado.nextInt();
        System.out.println("Los numeros ingresados son:");
        System.out.println(Numero1);
        System.out.println(Numero2);
        System.out.println(Numero3);
        System.out.println("El promedio es :");
        System.out.println((Numero1+Numero2+Numero3)/3); */ 

		// Se ingresan el lado de un cuadrado y se muestra el perimetro
   /*   Scanner Teclado = new Scanner (System.in);
        System.out.println("Ingrese Lado 1 del cuadrado:");
        int Numero1;
        Numero1 = Teclado.nextInt();
        System.out.println("El lado del cuadrado mide:");
        System.out.println(Numero1);
        System.out.println("El Perimetro del cuadrado es :");
        System.out.println(Numero1*4); */

		// Se ingresan el precio de un producto y se muestra el precio mas IVA
        Scanner Teclado = new Scanner (System.in);
        System.out.println("Ingrese el precio del producto:");
        int Numero1;
        Numero1 = Teclado.nextInt();
        System.out.println("El Precio del producto sin IVA es:");
        System.out.println(Numero1);
        System.out.println("El Precio del producto + IVA es:");
        System.out.println(Numero1+(Numero1*21)/100);
        
	}

}


