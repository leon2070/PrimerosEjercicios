package Uno;

public class Inicio {

	public static void main(String[] args) {
		// Esto es un comentario de una linea
		  /* 
		   * Esto es un comentario de varias lieas
		  */
		  System.out.println("Hola Mundo Leonardo");

	}

}
